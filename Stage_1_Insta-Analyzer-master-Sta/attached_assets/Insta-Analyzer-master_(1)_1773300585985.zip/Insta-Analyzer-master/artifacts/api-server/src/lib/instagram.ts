import axios from "axios";

export interface InstagramProfile {
  username: string;
  fullName: string;
  bio: string;
  followers: number;
  following: number;
  postsCount: number;
  isVerified: boolean;
  isPrivate: boolean;
  isBusinessAccount: boolean;
  profilePicUrl: string;
  engagementRate: number;
  avgLikes: number;
  avgComments: number;
  accountCategory: string;
  externalUrl: string;
}

function calcEngagement(followers: number, avgLikes: number, avgComments: number): number {
  if (followers <= 0) return 0;
  return parseFloat((((avgLikes + avgComments) / followers) * 100).toFixed(2));
}

function extractAvgLikesComments(recentMedia: any[]): { avgLikes: number; avgComments: number } {
  if (!recentMedia || recentMedia.length === 0) return { avgLikes: 0, avgComments: 0 };
  const totalLikes = recentMedia.reduce((sum: number, edge: any) => {
    const node = edge.node ?? edge;
    return sum + (node.edge_liked_by?.count ?? node.like_count ?? node.likes_count ?? 0);
  }, 0);
  const totalComments = recentMedia.reduce((sum: number, edge: any) => {
    const node = edge.node ?? edge;
    return sum + (node.edge_media_to_comment?.count ?? node.comment_count ?? node.comments_count ?? 0);
  }, 0);
  return {
    avgLikes: totalLikes / recentMedia.length,
    avgComments: totalComments / recentMedia.length,
  };
}

async function tryApi1(username: string): Promise<InstagramProfile> {
  const resp = await axios.get("https://instagram-scraper-api2.p.rapidapi.com/v1/info", {
    params: { username_or_id_or_url: username },
    headers: {
      "x-rapidapi-key": process.env.RAPIDAPI_KEY!,
      "x-rapidapi-host": "instagram-scraper-api2.p.rapidapi.com",
    },
    timeout: 12000,
  });

  const data = resp.data?.data;
  if (!data) throw new Error("No data in API1 response");

  const followers = data.follower_count ?? data.edge_followed_by?.count ?? 0;
  const following = data.following_count ?? data.edge_follow?.count ?? 0;
  const postsCount = data.media_count ?? data.edge_owner_to_timeline_media?.count ?? 0;
  const recentMedia = data.edge_owner_to_timeline_media?.edges ?? data.timeline_media ?? [];
  const { avgLikes, avgComments } = extractAvgLikesComments(recentMedia);

  return {
    username: data.username ?? username,
    fullName: data.full_name ?? "",
    bio: data.biography ?? "",
    followers,
    following,
    postsCount,
    isVerified: data.is_verified ?? false,
    isPrivate: data.is_private ?? false,
    isBusinessAccount: data.is_business_account ?? data.is_professional_account ?? false,
    profilePicUrl: data.profile_pic_url_hd ?? data.profile_pic_url ?? "",
    engagementRate: calcEngagement(followers, avgLikes, avgComments),
    avgLikes,
    avgComments,
    accountCategory: data.category_name ?? data.category ?? "",
    externalUrl: data.external_url ?? "",
  };
}

async function tryApi2(username: string): Promise<InstagramProfile> {
  const resp = await axios.get("https://instagram-looter2.p.rapidapi.com/account-info", {
    params: { username },
    headers: {
      "x-rapidapi-key": process.env.RAPIDAPI_KEY!,
      "x-rapidapi-host": "instagram-looter2.p.rapidapi.com",
    },
    timeout: 12000,
  });

  const data = resp.data;
  if (!data || !data.username) throw new Error("No data in API2 response");

  const followers = data.follower_count ?? data.edge_followed_by?.count ?? 0;
  const following = data.following_count ?? data.edge_follow?.count ?? 0;
  const postsCount = data.media_count ?? data.edge_owner_to_timeline_media?.count ?? 0;
  const recentMedia = data.edge_owner_to_timeline_media?.edges ?? [];
  const { avgLikes, avgComments } = extractAvgLikesComments(recentMedia);

  return {
    username: data.username ?? username,
    fullName: data.full_name ?? "",
    bio: data.biography ?? "",
    followers,
    following,
    postsCount,
    isVerified: data.is_verified ?? false,
    isPrivate: data.is_private ?? false,
    isBusinessAccount: data.is_business_account ?? data.is_professional_account ?? false,
    profilePicUrl: data.profile_pic_url_hd ?? data.profile_pic_url ?? "",
    engagementRate: calcEngagement(followers, avgLikes, avgComments),
    avgLikes,
    avgComments,
    accountCategory: data.category_name ?? data.category ?? "",
    externalUrl: data.external_url ?? "",
  };
}

async function tryApi3(username: string): Promise<InstagramProfile> {
  const resp = await axios.get("https://instagram-bulk-profile-scrapper.p.rapidapi.com/clients/api/ig/ig_profile", {
    params: { ig: username, response_type: "short", corsEnabled: "false" },
    headers: {
      "x-rapidapi-key": process.env.RAPIDAPI_KEY!,
      "x-rapidapi-host": "instagram-bulk-profile-scrapper.p.rapidapi.com",
    },
    timeout: 12000,
  });

  const arr = resp.data;
  const data = Array.isArray(arr) ? arr[0] : arr;
  if (!data || !data.username) throw new Error("No data in API3 response");

  const followers = data.follower_count ?? 0;
  const following = data.following_count ?? 0;
  const postsCount = data.media_count ?? 0;

  return {
    username: data.username ?? username,
    fullName: data.full_name ?? "",
    bio: data.biography ?? "",
    followers,
    following,
    postsCount,
    isVerified: data.is_verified ?? false,
    isPrivate: data.is_private ?? false,
    isBusinessAccount: data.is_business ?? data.is_business_account ?? false,
    profilePicUrl: data.profile_pic_url ?? "",
    engagementRate: 0,
    avgLikes: 0,
    avgComments: 0,
    accountCategory: data.category ?? "",
    externalUrl: data.external_url ?? "",
  };
}

export async function fetchInstagramProfile(username: string): Promise<InstagramProfile> {
  const clean = username.replace(/^@/, "").trim().toLowerCase();
  if (!clean) throw new Error("Username is required");

  const apis = [
    { name: "API1", fn: () => tryApi1(clean) },
    { name: "API2", fn: () => tryApi2(clean) },
    { name: "API3", fn: () => tryApi3(clean) },
  ];

  let lastError: any;
  for (const api of apis) {
    try {
      console.log(`[Instagram] Trying ${api.name} for @${clean}...`);
      const result = await api.fn();
      console.log(`[Instagram] ${api.name} succeeded for @${clean}`);
      return result;
    } catch (err: any) {
      const status = err?.response?.status;
      console.warn(`[Instagram] ${api.name} failed (${status ?? err?.message}) for @${clean}`);
      lastError = err;
      if (status === 404) break;
    }
  }

  const status = lastError?.response?.status;
  if (status === 404) throw new Error(`Profile @${clean} not found`);
  if (status === 403 || status === 401) {
    throw new Error(
      `API access denied (${status}). Make sure your RapidAPI key is subscribed to at least one of: instagram-scraper-api2, instagram-looter2, or instagram-bulk-profile-scrapper`
    );
  }
  throw new Error(lastError?.message ?? "Failed to fetch Instagram profile");
}
