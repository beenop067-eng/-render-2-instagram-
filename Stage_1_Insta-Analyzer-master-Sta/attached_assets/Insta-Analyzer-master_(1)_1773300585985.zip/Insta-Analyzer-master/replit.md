# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Instagram Analyzer Telegram Bot with a React dashboard.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Telegram**: node-telegram-bot-api
- **Instagram data**: RapidAPI (instagram-scraper-api2)
- **Frontend**: React + Vite + TailwindCSS + Framer Motion

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server (Telegram bot + Instagram API)
│   └── instagram-bot/      # React dashboard frontend
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Features

### Telegram Bot
- `/start` — welcome message with command list
- `/analyze <username>` — single-click full Instagram profile analysis
- Send any username directly (without command prefix) — auto-analyzed
- Returns: followers, following, posts, engagement rate, avg likes/comments, verified/private/business status, bio, category, external URL

### React Dashboard
- **Dashboard** — live bot status (polls every 5s), start/stop bot controls, stats cards, recent analyses table, system status panel, top profiles
- **Analyze Profile** — manual profile analyzer with single-click analysis and rich profile card display

## Environment Variables Required

- `TELEGRAM_BOT_TOKEN` — from @BotFather on Telegram
- `RAPIDAPI_KEY` — from rapidapi.com (uses instagram-scraper-api2)
- `DATABASE_URL` — auto-provisioned by Replit

## Key Files

- `artifacts/api-server/src/lib/bot.ts` — Telegram bot logic
- `artifacts/api-server/src/lib/instagram.ts` — Instagram API integration
- `artifacts/api-server/src/routes/bot.ts` — Bot control API routes
- `artifacts/api-server/src/routes/analytics.ts` — Analysis API routes
- `artifacts/api-server/src/app.ts` — Express app, auto-starts bot on server launch
- `lib/db/src/schema/analyses.ts` — Drizzle schema for storing analyses
- `artifacts/instagram-bot/src/pages/dashboard.tsx` — Main dashboard page
- `artifacts/instagram-bot/src/pages/analyze.tsx` — Manual analyzer page
